#include "types.h"
#include "user.h"



int main(int argc, char **argv){
  // srandom();
  printf(1, "Random number is: %d\n", random());

  exit();

  return 0;
}

# ifndef __DATE_H
# define __DATE_H

struct rtcdate {
  uint second;
  uint minute;
  uint hour;
  uint day;
  uint month;
  uint year;
};

#endif // __DATE_H

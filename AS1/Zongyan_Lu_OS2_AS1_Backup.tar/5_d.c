#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
	printf("Prob 5: execvp()\n");

	int pid = fork();

	if(0 == pid){
		char *ls_argv[] = {"ls", "-l", "-F", "-h", (char *) NULL};
		int status = execvp(ls_argv[0], ls_argv);
	}
	else{
		int stat_loc;
		pid = wait(&stat_loc);
	}
	return 0;
}

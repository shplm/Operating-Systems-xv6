#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
	printf("Prob 5: execlp()\n");
	int pid = fork();

	if(0 == pid){
		int status = execlp(
		"ls"
		, "ls", "-l", "-F", "-Bht", (char *) NULL);
	}
	else{
		int stat_loc;
		pid = wait(&stat_loc);
	}
	return 0;
}

#include <stdio.h>
#include <sys/types.h>

int main(){
	printf("------------------\n");
	printf("Prob 2 PART B\n");
	printf("------------------\n");

	int xx = 999;
	int pid = fork();
	if(pid == 0){
		xx = 777;
		printf("Variable 'xx' in child process is: %d\n", xx);
	}
	else{
		printf("Variable 'xx' in parent process is: %d\n", xx);
	}
	printf("\n\n");
	printf("After all changes, variable 'xx' now is: %d\n", xx);

	return 0;
}

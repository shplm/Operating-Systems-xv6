#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
	printf("Prob 5: execl()\n");
	int pid = fork();

	if(0 == pid){
		int status = execl(
		"/bin/ls"
		, "ls", "-l", "-F", "-h", (char *) NULL);
	}
	else{
		int stat_loc;
		pid = wait(&stat_loc);
	}
	return 0;
}

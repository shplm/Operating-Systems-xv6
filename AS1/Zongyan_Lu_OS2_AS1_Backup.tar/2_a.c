#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 

int main(){
	printf("------------------------\n");
	printf("Prob 2 FIRST PART\n");
	printf("------------------------\n");

	int xx = 100;

	int pid = fork();
	if(0 == pid){
		printf("Variable 'xx' in child process is: %d\n", xx);
	}
	else{
		printf("Variable 'xx' in parent process is: %d\n", xx);
	}
	
	return 0;
}

#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
	printf("Prob 5: execv()\n");
	int pid = fork();

	if(0 == pid){
		char * arr[] = {"ls", "-l", "-F", "-h", (char *) NULL};
		int status = execv(
		"/bin/ls"
		, arr);
	}
	else{
		int stat_loc;
		pid = wait(&stat_loc);
	}
	return 0;
}

#include "types.h"
#include "stat.h"
#include "user.h"

#define DIRSTR 128


int
mv(char *src, char *dest){
	int res = -1;

	if(link(src, dest) < 0){
		printf(2, "barf again\n");
	}//end if
	else{
		if(unlink(src) < 0){
			printf(2, "barf 3\n");
		}
		else{
			res = 0;
		}
	}//end else
	return res;
}//end ln func


int main(int argc, char *argv[]){

	int i = 0;
	int res = -1;
	char *dest = NULL;
	struct stat st;
	char dirstr[DIRSTR] = {0};

	if(argc < 3){
		printf(2, "barf\n");
		exit();
	}
	dest = argv[argc - 1];
	res = stat(dest, &st);
	if(res < 0){
		//dest does not exist
		mv(argv[1], dest);
	}//end if
	else{
		switch(st.type){
			case T_DIR:
				for(i = 1; i < (argc - 1); i++){
					memset(dirstr, 0, DIRSTR);
					strcpy(dirstr, dest);
					dirstr[strlen(dirstr)] = '/';
					strcpy(&(dirstr[strlen(dirstr)]), argv[i]);
					mv(argv[i], dirstr);
				}//end for
				break;
			case T_FILE:
				unlink(dest);
				mv(argv[1], dest);
				break;
			default:
				printf(2, "extra barf\n");
				break;
		}//end switch

	}//end else
	exit();
}

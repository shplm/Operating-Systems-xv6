#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
#ifdef SYMLINK
	if(argc != 3){
		printf(2, "wrong usage\n");
		exit();
	}//end if
	if(symlink(argv[1], argv[2]) < 0){
		printf(2, "failed\n");
	}//end if
#endif //SYMLINK
	exit();
}
